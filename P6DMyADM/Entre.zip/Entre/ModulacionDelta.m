%% Abrimos el archivo, vemos info y grafica
close all;
clear all;
clc;

nombreArvhivo='prueba.wav';
%audioinfo(nombreArvhivo)
[s,fs]=audioread(nombreArvhivo); 

s=s(:,1);
dt = 1/fs;
t = 0:dt:(length(s)*dt)-dt;
figure(1);
plot(t,s);
grid on;

%% Modulacion delta
paso=1/15;
% encoder
cn=DeltaModEnc(s,paso);
% decoder
sn=DeltaModDec(paso,fs,cn);
audiowrite('pruebaDm.wav',sn,fs)

%% modulaci�n delta adaptativa
[acod,del]=AdDeltaModEnc(s,fs);
asn=AdDeltaDec(acod,del,s);
audiowrite('pruebaADm.wav',asn,fs);

